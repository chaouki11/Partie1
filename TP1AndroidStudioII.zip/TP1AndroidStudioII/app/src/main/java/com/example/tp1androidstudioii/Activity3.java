package com.example.tp1androidstudioii;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {

    Button btnquitter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        btnquitter = (Button) findViewById(R.id.btnquitter);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3);
        btnquitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}
